package com.alarm.project.ddenry.alarmmanager;

public interface AsyncTaskDone {
    void onSucceed();

    void onFailed();
}
